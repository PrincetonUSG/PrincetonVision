Princeton Vision
Authors: Di Qi '18 and Samuel Russell '18

Imports data from Tigerbook into gmail to display information about majors, years, and profile pictures.
Will not work for non-Princeton students.